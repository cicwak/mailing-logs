from .mailing_logs import MailingLogs
